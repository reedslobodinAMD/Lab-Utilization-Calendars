from at_scale_python_api.backend.endpoint import Endpoint
from at_scale_python_api.routes import Route


class Upload(Endpoint):
    route = Route.UPLOAD

    def post(self, file_name: str, creator_email: str, file_contents: str):
        files = {"file": (file_name, file_contents)}
        data = {"creator_email": creator_email}
        return self.requester.post(self.route, data=data, files=files)

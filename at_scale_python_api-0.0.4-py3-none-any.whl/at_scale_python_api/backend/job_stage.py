from at_scale_python_api.backend.endpoint import Endpoint
from at_scale_python_api.routes import Route


class JobStage(Endpoint):
    route = Route.JOB_STAGE
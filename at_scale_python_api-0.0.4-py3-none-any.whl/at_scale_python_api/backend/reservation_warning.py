from at_scale_python_api.backend.endpoint import Endpoint
from at_scale_python_api.routes import Route


class ReservationWarning(Endpoint):
    route = Route.RESERVATION_WARNING
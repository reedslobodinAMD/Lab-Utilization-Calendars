import abc
from typing import Any, Dict

import requests
import urllib3

from at_scale_python_api.environment import (
    AMD_EMAIL,
    ATS_SECRET,
    REQUEST_TIMEOUT,
    VERIFY_CERTS,
)

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


class RequestError(Exception):
    pass


class AuthorizationError(Exception):
    pass


class RequestEngine:
    def __init__(self):
        self.headers = {
            "Authorization": (AMD_EMAIL + ":" + ATS_SECRET) if AMD_EMAIL else ATS_SECRET
        }

    def get(self, route: str, data: Dict = None):
        if data is None:
            data = {}
        res = requests.get(
            route,
            headers=self.headers,
            json=data,
            verify=VERIFY_CERTS,
            timeout=REQUEST_TIMEOUT,
        )

        try:
            contents = res.json()
        except requests.exceptions.JSONDecodeError:
            contents = ""
        if res.status_code == 401:
            raise AuthorizationError(str(contents))
        elif res.status_code >= 400:
            raise RequestError(str(contents))
        return contents

    def post(self, route: str, data: Dict = None, files: Any = None):
        if data is None:
            data = {}
        if files:
            res = requests.post(
                route,
                headers=self.headers,
                data=data,
                files=files,
                verify=VERIFY_CERTS,
                timeout=REQUEST_TIMEOUT,
            )
        else:
            res = requests.post(
                route,
                headers=self.headers,
                json=data,
                verify=VERIFY_CERTS,
                timeout=REQUEST_TIMEOUT,
            )
        try:
            contents = res.json()
        except requests.exceptions.JSONDecodeError:
            contents = ""
        if res.status_code == 401:
            raise AuthorizationError(str(contents))
        elif res.status_code >= 400:
            raise RequestError(str(contents))
        return contents

    def put(self, route: str, data: Dict = None):
        if data is None:
            data = {}
        res = requests.put(
            route,
            headers=self.headers,
            json=data,
            verify=VERIFY_CERTS,
            timeout=REQUEST_TIMEOUT,
        )
        try:
            contents = res.json()
        except requests.exceptions.JSONDecodeError:
            contents = ""
        if res.status_code == 401:
            raise AuthorizationError(str(contents))
        elif res.status_code >= 400:
            raise RequestError(str(contents))
        return contents

    def delete(self, route: str, data: Dict = None):
        res = requests.delete(
            route,
            headers=self.headers,
            json=data,
            verify=VERIFY_CERTS,
            timeout=REQUEST_TIMEOUT,
        )
        try:
            contents = res.json()
        except requests.exceptions.JSONDecodeError:
            contents = ""
        if res.status_code == 401:
            raise AuthorizationError(str(contents))
        elif res.status_code >= 400:
            raise RequestError(str(contents))
        return contents


class Endpoint(abc.ABC):
    route = ""
    model = None
    schema = None

    def __init__(self):
        self.requester = RequestEngine()

    def _clear_unused(self, data: Dict) -> Dict:
        used_data = {}
        for key, value in data.items():
            if value is not None:
                used_data[key] = value
        return used_data

    def get(self, identifier=None, **kwargs):
        data = kwargs
        if identifier is not None:
            data["id"] = identifier
        return self.requester.get(self.route, data=data)

    def delete(self, identifier):
        data = {
            "id": identifier,
        }
        return self.requester.delete(self.route, data=data)

    def post(
        self,
        *args,
        **kwargs,
    ):
        if len(args) == 1 and isinstance(args[0], list):
            data = [self._clear_unused(x) for x in args[0]]
        elif len(args) == 1 and isinstance(args[0], dict):
            data = self._clear_unused(args[0])
        else:
            data = self._clear_unused(kwargs)
        return self.requester.post(self.route, data=data)

    def put(
        self,
        identifier,
        **kwargs,
    ):
        kwargs["id"] = identifier
        data = self._clear_unused(kwargs)
        return self.requester.put(self.route, data=data)

from at_scale_python_api.backend.endpoint import Endpoint
from at_scale_python_api.routes import Route


class DataBackedQueue(Endpoint):
    route = Route.DATA_BACKED_QUEUE
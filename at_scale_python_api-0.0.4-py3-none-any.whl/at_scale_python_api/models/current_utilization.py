from at_scale_python_api.models.model import Model


class CurrentUtilization(Model):
    def __init__(self, **kwargs):
        super().__init__()
        self.utilization: float = None
        self.from_dict(kwargs)

from at_scale_python_api.models.model import Model


class CallbackTriggerPost(Model):
    def __init__(self, **kwargs):
        super().__init__()
        self.event: str = None
        self.associated_record_id: str = None
        self.associated_record_store_name: str = None
        self.from_dict(kwargs)

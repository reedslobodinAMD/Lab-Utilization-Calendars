from typing import List

from at_scale_python_api.models.model import Model

# keeping this one around with inconsistent naming for backwards compatibility
class DataBackedQueueInputSchema(Model):
    def __init__(self, **kwargs):
        super().__init__()
        self.data_backed_project_id: str = None
        self.job_set_id: str = None
        self.definition_dir: str = None
        self.creator_email: str = None
        self.test_file: str = None
        self.project_type: str = None
        self.variable_files: List[str] = None
        self.final_config_id: str = None
        self.test_list_name: str = None
        self.from_dict(kwargs)


class DataBackedQueuePost(Model):
    def __init__(self, **kwargs):
        super().__init__()
        self.data_backed_project_id: str = None
        self.job_set_id: str = None
        self.definition_dir: str = None
        self.creator_email: str = None
        self.test_file: str = None
        self.project_type: str = None
        self.variable_files: List[str] = None
        self.final_config_id: str = None
        self.test_list_name: str = None
        self.from_dict(kwargs)

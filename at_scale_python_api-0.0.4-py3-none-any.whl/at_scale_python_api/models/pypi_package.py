from at_scale_python_api.models.model import Model


class PypiPackage(Model):
    def __init__(self, **kwargs):
        super().__init__()
        self.name: str = None
        self.filename: str = None
        self.last_modified: int = None
        self.version: str = None
        self.url: str = None
        self.summary: str = None
        self.from_dict(kwargs)

from at_scale_python_api.models.model import Model


class CurrentUtilizationPost(Model):
    def __init__(self, **kwargs):
        super().__init__()
        self.team_id: str = None
        self.pool_id: str = None
        self.date_time_start: str = None
        self.date_time_end: str = None
        self.duration_min: int = None
        self.consider_batch_jobs: bool = False
        self.from_dict(kwargs)

from typing import Dict

from at_scale_python_api.models.model import Model


class SystemEvent(Model):
    def __init__(self, **kwargs):
        super().__init__()
        self.system_id: str = None
        self.event_type: str = None
        self.event_description: str = None
        self.event_details: Dict = {}
        self.job_id: str = None
        self.from_dict(kwargs)
from at_scale_python_api.models.model import Model

class JenkinsJob(Model):
    def __init__(self, **kwargs):
        super().__init__()
        self.from_dict(kwargs)
from at_scale_python_api.models.config import Config
from at_scale_python_api.models.model import Model


class TestCase(Model):
    def __init__(self, **kwargs):
        super().__init__(
            model_attrs=dict(
                config=Config,
            )
        )
        self.name: str = None
        self.test_type: str = None
        self.test_module: str = None
        self.archived: bool = False
        self.creator_email: str = None
        self.config_id: str = None
        self.config: Config = None
        self.from_dict(kwargs)

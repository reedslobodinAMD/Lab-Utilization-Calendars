from at_scale_python_api.models.model import Model


class TeamAllocation(Model):
    def __init__(self, **kwargs):
        super().__init__()
        self.date_start: str = None
        self.date_end: str = None
        self.team_id: str = None
        self.pool_id: str = None
        self.percent_allocation: float = None
        self.from_dict(kwargs)

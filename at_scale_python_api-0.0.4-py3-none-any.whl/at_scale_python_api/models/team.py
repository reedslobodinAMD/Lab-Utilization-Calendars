from at_scale_python_api.models.model import Model
from at_scale_python_api.models.pool import Pool


class Team(Model):
    def __init__(self, **kwargs):
        super().__init__(
            model_attrs=dict(
                pools=Pool,
            )
        )
        self.name: str = None
        self.global_system_access: bool = False
        self.from_dict(kwargs)

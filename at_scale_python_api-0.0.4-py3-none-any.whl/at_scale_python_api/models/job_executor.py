from typing import Dict

from at_scale_python_api.models.model import Model


class JobExecutor(Model):
    def __init__(self, **kwargs):
        super().__init__()
        self.type: str = None
        self.details: Dict = {}
        self.from_dict(kwargs)

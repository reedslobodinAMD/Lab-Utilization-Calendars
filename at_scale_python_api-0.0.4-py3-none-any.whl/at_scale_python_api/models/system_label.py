from at_scale_python_api.models.model import Model


class SystemLabel(Model):
    def __init__(self, **kwargs):
        super().__init__()
        self.description: str = None
        self.name: str = None
        self.from_dict(kwargs)
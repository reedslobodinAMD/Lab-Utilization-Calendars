from typing import Dict

from at_scale_python_api.models.model import Model


class Config(Model):
    def __init__(self, **kwargs):
        super().__init__()
        self.name: str = None
        self.contents: Dict = {}
        self.hidden: bool = None
        self.archived: bool = None
        self.prev_id: str = None
        self.creator_email: str = None
        self.from_dict(kwargs)

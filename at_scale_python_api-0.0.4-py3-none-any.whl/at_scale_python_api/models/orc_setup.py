from at_scale_python_api.models.model import Model


class OrcSetup(Model):
    def __init__(self, **kwargs):
        super().__init__()
        self.mw_version: str = None
        self.orc_version: str = None
        self.recover_reboot_hang: bool = True
        self.recover_reboot_hang: bool = True
        self.force_poweroff_workaround: bool = False
        self.from_dict(kwargs)

from at_scale_python_api.models.model import Model


class ExecutorPayloadPost(Model):
    def __init__(self, **kwargs):
        super().__init__()
        self.job_set_id: str = None
        self.from_dict(kwargs)

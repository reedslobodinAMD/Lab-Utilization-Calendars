from typing import List

from at_scale_python_api.models.apu_sku import ApuSku
from at_scale_python_api.models.job_executor import JobExecutor
from at_scale_python_api.models.model import Model
from at_scale_python_api.models.system_data import SystemData
from at_scale_python_api.models.system_label import SystemLabel
from at_scale_python_api.models.system_state import SystemState
from at_scale_python_api.models.pool import Pool


class System(Model):
    def __init__(self, **kwargs):
        super().__init__(
            model_attrs=dict(
                system_labels=SystemLabel,
                system_datas=SystemData,
                job_executors=JobExecutor,
                system_states=SystemState,
                apu_skus=ApuSku,
                pool=Pool
            )
        )
        self.system_data_id: str = None
        self.system_labels: List[SystemLabel] = []
        self.system_datas: SystemData = None
        self.password: str = None
        self.job_executor_id: str = None
        self.job_executors: JobExecutor = None
        self.pool_id: str = None
        self.pool: Pool = None
        self.apu_sku_id: str = None
        self.system_state_id: str = None
        self.apu_skus: ApuSku = None
        self.platform_power_controller_type_user: str = None
        self.system_states: SystemState = None
        self.system_source_id: str = None
        self.job_executor_ref_id: str = None
        self.platform_power_controller_type_ip: str = None
        self.platform_power_controller_type: str = None
        self.platform_power_controller_type_pass: str = None
        self.from_dict(kwargs)

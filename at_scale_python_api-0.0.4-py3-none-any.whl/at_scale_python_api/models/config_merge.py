from typing import Dict, List

from at_scale_python_api.models.model import Model


class ConfigMerge(Model):
    def __init__(self, **kwargs):
        super().__init__()
        self.contents: str = None
        self.json_contents: Dict = {}
        self.from_dict(kwargs)

from typing import Dict

from at_scale_python_api.models.model import Model


class Apu(Model):
    def __init__(self, **kwargs):
        super().__init__()
        self.name: str = None
        self.abbr: str = None
        self.from_dict(kwargs)

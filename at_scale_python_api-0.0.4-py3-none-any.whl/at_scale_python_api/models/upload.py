from at_scale_python_api.models.model import Model


class Upload(Model):
    def __init__(self, **kwargs):
        super().__init__()
        self.file_name: str = None
        self.creator_email: str = None
        self.file_contents: str = None
        self.from_dict(kwargs)

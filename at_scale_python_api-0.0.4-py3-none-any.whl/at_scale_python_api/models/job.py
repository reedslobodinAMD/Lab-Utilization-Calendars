from typing import List

from at_scale_python_api.models.job_set import JobSet
from at_scale_python_api.models.job_stage import JobStage
from at_scale_python_api.models.model import Model
from at_scale_python_api.models.system import System


class Job(Model):
    def __init__(self, **kwargs):
        super().__init__(
            model_attrs=dict(job_stages=JobStage, job_set=JobSet, system=System)
        )
        self.date_end: str = None
        self.date_start: str = None
        self.job_set: JobSet = None
        self.system: System = None
        self.system_id: str = None
        self.job_stages: List[JobStage] = []
        self.job_set_id: str = None
        self.live_stdout_log_url: str = None
        self.job_exec_runid: str = None
        self.state: str = None
        self.aborted: bool = False
        self.preempted: bool = False
        self.result: str = None
        self.orc3db_scheduler_id: str = None
        self.date_state_change: str = None
        self.artifact_url: str = None
        self.reservation_ids: List[str] = []
        self.from_dict(kwargs)

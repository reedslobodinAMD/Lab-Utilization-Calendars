from typing import List

from at_scale_python_api.models.model import Model


class StackSetup(Model):
    def __init__(self, **kwargs):
        super().__init__()
        self.name: str = None
        self.bkc: bool = False
        self.ensure_driver_load: bool = False
        self.rocm_type: str = None
        self.rocm_buildno: str = None
        self.rocm_release_branch: str = None
        self.ifwi: str = None
        self.sbios: str = None
        self.ignore_rocm_pkg_err: List[str] = []
        self.amdvbflash_tar_url: str = None
        self.creator_email: str = None
        self.amdgpu_build: str = None
        self.amdgpu_modprobe_args: str = None
        self.from_dict(kwargs)

from typing import Dict

from at_scale_python_api.models.model import Model
from at_scale_python_api.models.apu import Apu


class ApuSku(Model):
    def __init__(self, **kwargs):
        super().__init__(
             model_attrs=dict(
                apus=Apu,
            )
        )
        self.name: str = None
        self.bkc_type: str = None
        self.sku: str = None
        self.short_id: str = None
        self.liquid_cooled: bool = False
        self.apu_id: str = None
        self.apus: Apu = None
        self.other_data: Dict = {}
        self.from_dict(kwargs)

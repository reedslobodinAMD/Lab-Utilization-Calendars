from typing import Dict, List

from at_scale_python_api.models.model import Model


class RawConfigMergePost(Model):
    def __init__(self, **kwargs):
        super().__init__()
        self.configs: List[Dict] = []
        self.test_list_id: str = None
        self.strategy: str = None
        self.from_dict(kwargs)

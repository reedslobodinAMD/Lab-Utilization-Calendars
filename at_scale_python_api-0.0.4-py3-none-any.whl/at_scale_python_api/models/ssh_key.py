from at_scale_python_api.models.model import Model
from at_scale_python_api.models.pool import Pool


class SshKey(Model):
    def __init__(self, **kwargs):
        super().__init__()
        self.title: str = None
        self.key: bool = None
        self.fingerprint: str = None
        self.user_id: str = None
        self.from_dict(kwargs)

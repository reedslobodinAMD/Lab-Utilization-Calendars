from typing import List

from at_scale_python_api.models.model import Model
from at_scale_python_api.models.test_case import TestCase


class TestList(Model):
    def __init__(self, **kwargs):
        super().__init__(
            model_attrs=dict(
                test_cases=TestCase,
            )
        )
        self.name: str = None
        self.description: str = None
        self.creator_email: str = None
        self.labels: List[str] = []
        self.public: bool = False
        self.archived: bool = False
        self.prev_id: str = None
        self.test_cases: List[TestCase] = []
        self.test_case_ids: List[str] = []
        self.from_dict(kwargs)

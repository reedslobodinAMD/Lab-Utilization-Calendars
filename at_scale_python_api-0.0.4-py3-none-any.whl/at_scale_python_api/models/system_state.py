from typing import List

from at_scale_python_api.models.model import Model


class SystemState(Model):
    def __init__(self, **kwargs):
        super().__init__()
        self.ssh_enabled: bool = None
        self.date_last_job_complete: str = None
        self.reserved_by: List[str] = None
        self.disabled_reason: str = None
        self.disable_return_online_time: str = None
        self.disabled_by: str = None
        self.disabled: bool = None
        self.date_reimaged: str = None
        self.from_dict(kwargs)

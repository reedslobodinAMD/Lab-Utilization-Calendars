from typing import List

from at_scale_python_api.models.model import Model


class ReservationPost(Model):
    def __init__(self, **kwargs):
        super().__init__()
        self.title: str = None
        self.description: str = None
        self.user_ids: List[str] = None
        # for backwards compat
        self.user_id: str = None
        self.team_id: str = None
        self.system_id: str = None
        self.date_time_start: str = None
        self.date_time_end: str = None
        self.from_dict(kwargs)

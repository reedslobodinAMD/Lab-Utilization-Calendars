from typing import List

from at_scale_python_api.models.model import Model
from at_scale_python_api.models.system import System
from at_scale_python_api.models.team import Team
from at_scale_python_api.models.user import User


class ReservationResponse(Model):
    def __init__(self, **kwargs):
        super().__init__(
            model_attrs=dict(
                users=User,
                system=System,
                team=Team,
            )
        )
        self.title: str = None
        self.description: str = None
        self.team_id: str = None
        self.system_id: str = None
        self.date_time_start: str = None
        self.date_time_end: str = None
        self.users: List[User] = []
        self.system: System = None
        self.team: Team = None
        self.from_dict(kwargs)

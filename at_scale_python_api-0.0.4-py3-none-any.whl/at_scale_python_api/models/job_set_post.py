from typing import List

from at_scale_python_api.models.model import Model


class JobSetPost(Model):
    def __init__(self, **kwargs):
        super().__init__()
        self.name: str = None
        self.system_ids: List[str] = None
        self.config_ids: List[str] = None
        self.pool_id: str = None
        self.team_id: str = None
        self.test_list_id: str = None
        self.stack_setup_id: str = None
        self.submitter: str = None
        self.source = "REST"
        self.priority = 5
        self.rerun_num = None
        self.expire_date: str = None
        self.date_start: str = None
        self.target: str = None
        self.disabled: bool = False
        self.mw_version: str = None
        self.orc_version: str = None
        self.dispatcher_version: str = None
        self.recover_reboot_hang: bool = True
        self.recover_test_hang: bool = True
        self.requeue_on_preemption: bool = True
        self.force_poweroff_workaround: bool = False
        self.email_results: bool = True
        self.disable_system_on_failure: bool = False
        self.disable_system_on_failure_comment: str = None
        self.run_dispatcher: bool = False
        self.final_config_id: str = None
        self.execution_mechanism = None
        self.system_label_ids: List[str] = []
        self.data_backed_project_id: str = None
        self.num_of_systems: int = None
        self.estimated_runtime_hours: float = None
        self.type: str = None
        self.from_dict(kwargs)

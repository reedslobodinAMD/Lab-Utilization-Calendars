from typing import Dict, List

from at_scale_python_api.models.model import Model


class Pool(Model):
    def __init__(self, **kwargs):
        super().__init__()
        self.name: str = None
        self.details: Dict = None
        self.exclusive: bool = False
        self.free_for_all: bool = False
        self.group_restrictions: str = None
        self.allow_floor_sweeper: bool = False
        self.allow_error_scraper: bool = False
        self.from_dict(kwargs)

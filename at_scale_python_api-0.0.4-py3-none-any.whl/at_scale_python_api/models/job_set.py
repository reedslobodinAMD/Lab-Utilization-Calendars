from typing import List

from at_scale_python_api.models.config import Config
from at_scale_python_api.models.model import Model
from at_scale_python_api.models.stack_setup import StackSetup
from at_scale_python_api.models.system_label import SystemLabel
from at_scale_python_api.models.test_list import TestList


class JobSet(Model):
    def __init__(self, **kwargs):
        from at_scale_python_api.models.job import Job

        super().__init__(
            model_attrs=dict(
                system_labels=SystemLabel,
                jobs=Job,
                test_lists=TestList,
                stack_setups=StackSetup,
                configs=Config,
                final_config=Config,
            )
        )
        self.name: str = None
        self.system_ids: List[str] = None
        self.config_ids: List[str] = None
        self.pool_id: str = None
        self.team_id: str = None
        self.test_list_id: str = None
        self.stack_setup_id: str = None
        self.submitter: str = None
        self.source = "REST"
        self.priority = 5
        self.rerun_num = None
        self.expire_date: str = None
        self.date_start: str = None
        self.date_end: str = None
        self.target: str = None
        self.disabled: bool = False
        self.mw_version: str = None
        self.orc_version: str = None
        self.dispatcher_version: str = None
        self.recover_reboot_hang: bool = True
        self.recover_test_hang: bool = True
        self.requeue_on_preemption: bool = True
        self.force_poweroff_workaround: bool = False
        self.email_results: bool = True
        self.disable_system_on_failure: bool = False
        self.disable_system_on_failure_comment: str = None
        self.run_dispatcher: bool = False
        self.jobs: List[Job] = []
        self.test_lists: TestList = None
        self.stack_setups: StackSetup = None
        self.configs: List[Config] = []
        self.final_config_id: str = None
        self.final_config: Config = None
        self.execution_mechanism = None
        self.system_labels: List[SystemLabel] = []
        self.data_backed_project_id: str = None
        self.type: str = None
        self.from_dict(kwargs)

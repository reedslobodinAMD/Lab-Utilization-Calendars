from typing import Dict

from at_scale_python_api.models.model import Model


class SystemData(Model):
    def __init__(self, **kwargs):
        super().__init__()
        self.username: str = None
        self.scraped_data: Dict = {}
        self.platform_config: Dict = {}
        self.name: str = None
        self.hostname_ip: str = None
        self.from_dict(kwargs)

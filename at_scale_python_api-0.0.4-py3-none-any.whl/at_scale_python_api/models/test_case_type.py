from at_scale_python_api.models.model import Model


class TestCaseType(Model):
    def __init__(self, **kwargs):
        super().__init__()
        self.name: str = None
        self.hidden: bool = True
        self.from_dict(kwargs)

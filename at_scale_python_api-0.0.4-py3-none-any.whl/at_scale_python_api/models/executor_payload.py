from typing import Dict

from at_scale_python_api.models.model import Model


class ExecutorPayload(Model):
    def __init__(self, **kwargs):
        super().__init__()
        self.name: str = None
        self.type: str = None
        self.module: str = None
        self.args: Dict = {}
        self.from_dict(kwargs)

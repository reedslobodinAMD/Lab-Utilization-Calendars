from typing import List

from at_scale_python_api.models.model import Model


class ConfigMergePost(Model):
    def __init__(self, **kwargs):
        super().__init__()
        self.config_ids: List[str] = []
        self.test_list_id: str = None
        self.strategy: str = None
        self.from_dict(kwargs)

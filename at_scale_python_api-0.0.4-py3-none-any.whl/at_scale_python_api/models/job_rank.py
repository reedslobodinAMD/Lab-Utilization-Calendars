from at_scale_python_api.models.model import Model


class JobRank(Model):
    def __init__(self, **kwargs):
        super().__init__()
        self.team_id: str = ""
        self.pool_id: str = ""
        self.rank: int = 0
        self.from_dict(kwargs)

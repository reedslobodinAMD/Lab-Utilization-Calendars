from at_scale_python_api.models.model import Model


class JobStage(Model):
    def __init__(self, **kwargs):
        super().__init__()
        self.name: str = None
        self.state: str = None
        self.job_id: str = None
        self.log_start_line: int = -1
        self.log_end_line: int = -1
        self.from_dict(kwargs)

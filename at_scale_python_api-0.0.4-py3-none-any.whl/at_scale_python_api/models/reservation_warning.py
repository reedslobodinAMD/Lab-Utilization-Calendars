from at_scale_python_api.models.model import Model


class ReservationWarning(Model):
    def __init__(self, **kwargs):
        super().__init__()
        self.reservation_id: str = None
        self.last_notification: str = None
        self.from_dict(kwargs)

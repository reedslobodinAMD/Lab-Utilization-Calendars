from typing import List

from at_scale_python_api.models.model import Model
from at_scale_python_api.models.team import Team


class User(Model):
    def __init__(self, **kwargs):
        super().__init__(model_attrs=dict(teams=Team))
        self.aad_id: str = None
        self.short_id: str = None
        self.email: str = None
        self.teams: List[Team] = None
        self.full_name: str = None
        self.superuser: bool = False
        self.groups: List[str] = None
        self.from_dict(kwargs)

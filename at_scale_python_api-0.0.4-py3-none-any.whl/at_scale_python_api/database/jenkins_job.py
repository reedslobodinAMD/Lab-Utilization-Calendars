from at_scale_python_api import models
from at_scale_python_api.backend import JenkinsJob
from at_scale_python_api.database.database import DatabaseController

JENKINS_JOB_DB_CONTROLLER = DatabaseController(
    model=models.JenkinsJob, endpoint=JenkinsJob()
)

from at_scale_python_api import models
from at_scale_python_api.backend import PypiPackage
from at_scale_python_api.database.database import DatabaseController

PYPI_PACKAGE_DB_CONTROLLER = DatabaseController(
    model=models.PypiPackage, endpoint=PypiPackage()
)

from at_scale_python_api import models
from at_scale_python_api.backend import CalendarReservation
from at_scale_python_api.database.database import DatabaseController

RESERVATION_DB_CONTROLLER = DatabaseController(
    model=models.ReservationResponse, endpoint=CalendarReservation()
)

from at_scale_python_api import models
from at_scale_python_api.backend import RawConfigMerge
from at_scale_python_api.database.database import DatabaseController

RAW_CONFIG_MERGE_DB_CONTROLLER = DatabaseController(
    model=models.ConfigMerge, endpoint=RawConfigMerge()
)

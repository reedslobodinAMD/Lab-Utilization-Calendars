from at_scale_python_api import models
from at_scale_python_api.backend import PoolCurrentUtilization
from at_scale_python_api.database.database import DatabaseController

POOL_CURRENT_UTILIZATION_DB_CONTROLLER = DatabaseController(
    model=models.CurrentUtilization, endpoint=PoolCurrentUtilization()
)

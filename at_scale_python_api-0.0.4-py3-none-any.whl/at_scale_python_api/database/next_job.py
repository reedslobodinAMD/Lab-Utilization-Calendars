from at_scale_python_api import models
from at_scale_python_api.backend import NextJob
from at_scale_python_api.database.database import DatabaseController

NEXT_JOB_DB_CONTROLLER = DatabaseController(model=models.Job, endpoint=NextJob())

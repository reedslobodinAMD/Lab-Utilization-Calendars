from at_scale_python_api import models
from at_scale_python_api.backend import SshKey
from at_scale_python_api.database.database import DatabaseController

SSH_KEY_DB_CONTROLLER = DatabaseController(model=models.SshKey, endpoint=SshKey())

from at_scale_python_api import models
from at_scale_python_api.backend import Upload
from at_scale_python_api.database.database import DatabaseController

UPLOAD_DB_CONTROLLER = DatabaseController(model=models.Upload, endpoint=Upload())

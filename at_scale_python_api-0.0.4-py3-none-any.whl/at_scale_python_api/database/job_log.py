from at_scale_python_api import models
from at_scale_python_api.backend import JobLog
from at_scale_python_api.database.database import DatabaseController

JOB_LOG_DB_CONTROLLER = DatabaseController(model=models.JobLog, endpoint=JobLog())

from at_scale_python_api import models
from at_scale_python_api.backend import JenkinsKill
from at_scale_python_api.database.database import DatabaseController

JENKINS_KILL_DB_CONTROLLER = DatabaseController(
    model=models.JenkinsJob, endpoint=JenkinsKill()
)
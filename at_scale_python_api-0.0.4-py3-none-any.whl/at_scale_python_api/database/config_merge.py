from at_scale_python_api import models
from at_scale_python_api.backend import ConfigMerge
from at_scale_python_api.database.database import DatabaseController

CONFIG_MERGE_DB_CONTROLLER = DatabaseController(
    model=models.ConfigMerge, endpoint=ConfigMerge()
)

from at_scale_python_api import models
from at_scale_python_api.backend import TestCaseType
from at_scale_python_api.database.database import DatabaseController

TEST_CASE_TYPE_DB_CONTROLLER = DatabaseController(
    model=models.TestCaseType, endpoint=TestCaseType()
)

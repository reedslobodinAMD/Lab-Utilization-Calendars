from at_scale_python_api import models
from at_scale_python_api.backend import DataBackedProject
from at_scale_python_api.database.database import DatabaseController

DATA_BACKED_PROJECT_DB_CONTROLLER = DatabaseController(
    model=models.DataBackedProject, endpoint=DataBackedProject()
)

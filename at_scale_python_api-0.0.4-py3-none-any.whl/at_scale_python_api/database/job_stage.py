from at_scale_python_api import models
from at_scale_python_api.backend import JobStage
from at_scale_python_api.database.database import DatabaseController

JOB_STAGE_DB_CONTROLLER = DatabaseController(model=models.JobStage, endpoint=JobStage())

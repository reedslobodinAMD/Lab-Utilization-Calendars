from at_scale_python_api import models
from at_scale_python_api.backend import Team
from at_scale_python_api.database.database import DatabaseController

TEAM_DB_CONTROLLER = DatabaseController(model=models.Team, endpoint=Team())

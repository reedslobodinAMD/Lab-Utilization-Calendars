from at_scale_python_api import models
from at_scale_python_api.backend import SystemData
from at_scale_python_api.database.database import DatabaseController

SYSTEM_DATA_DB_CONTROLLER = DatabaseController(
    model=models.SystemData, endpoint=SystemData()
)

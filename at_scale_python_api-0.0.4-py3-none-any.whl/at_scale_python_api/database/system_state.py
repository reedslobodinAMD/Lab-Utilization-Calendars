from at_scale_python_api import models
from at_scale_python_api.backend import SystemState
from at_scale_python_api.database.database import DatabaseController

SYSTEM_STATE_DB_CONTROLLER = DatabaseController(
    model=models.SystemState, endpoint=SystemState()
)

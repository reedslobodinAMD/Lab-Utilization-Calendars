from at_scale_python_api import models
from at_scale_python_api.backend import ExecutorPayload
from at_scale_python_api.database.database import DatabaseController

EXECUTOR_PAYLOAD_DB_CONTROLLER = DatabaseController(
    model=models.ExecutorPayload, endpoint=ExecutorPayload()
)

from at_scale_python_api import models
from at_scale_python_api.backend import TestCase
from at_scale_python_api.database.database import DatabaseController

TEST_CASE_DB_CONTROLLER = DatabaseController(model=models.TestCase, endpoint=TestCase())

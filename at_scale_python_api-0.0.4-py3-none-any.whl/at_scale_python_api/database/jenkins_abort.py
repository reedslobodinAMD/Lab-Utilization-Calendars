from at_scale_python_api import models
from at_scale_python_api.backend import JenkinsAbort
from at_scale_python_api.database.database import DatabaseController

JENKINS_ABORT_DB_CONTROLLER = DatabaseController(
    model=models.JenkinsJob, endpoint=JenkinsAbort()
)

from at_scale_python_api import models
from at_scale_python_api.backend import JobSet
from at_scale_python_api.database.database import DatabaseController

JOB_SET_DB_CONTROLLER = DatabaseController(model=models.JobSet, endpoint=JobSet())

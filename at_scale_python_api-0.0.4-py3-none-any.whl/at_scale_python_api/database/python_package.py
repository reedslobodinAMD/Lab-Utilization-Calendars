from at_scale_python_api import models
from at_scale_python_api.backend import PythonPackage
from at_scale_python_api.database.database import DatabaseController

PYTHON_PACKAGE_DB_CONTROLLER = DatabaseController(
    model=models.PythonPackage, endpoint=PythonPackage()
)

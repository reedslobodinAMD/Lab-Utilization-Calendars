from at_scale_python_api import models
from at_scale_python_api.backend import BatchRank
from at_scale_python_api.database.database import DatabaseController

BATCH_RANK_DB_CONTROLLER = DatabaseController(
    model=models.JobRank, endpoint=BatchRank()
)

from at_scale_python_api import models
from at_scale_python_api.backend import SystemAccess
from at_scale_python_api.database.database import DatabaseController

SYSTEM_ACCESS_DB_CONTROLLER = DatabaseController(
    model=models.System, endpoint=SystemAccess()
)

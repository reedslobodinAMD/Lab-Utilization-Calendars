from at_scale_python_api import models
from at_scale_python_api.backend import ReservationWarning
from at_scale_python_api.database.database import DatabaseController

RESERVATION_WARNING_DB_CONTROLLER = DatabaseController(
    model=models.ReservationWarning, endpoint=ReservationWarning()
)

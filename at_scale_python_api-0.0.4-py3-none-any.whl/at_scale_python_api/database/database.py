import os
from typing import Dict, List, Union

from at_scale_python_api.ats_logging import get_logger

logger = get_logger(__name__ + str(os.getpid()), print_logs=False)


from at_scale_python_api import models
from at_scale_python_api.backend import (
    Endpoint,
    RequestError,
)


def suppress_errors(func):
    def wrapper(self, *args, **kwargs):
        try:
            return func(self, *args, **kwargs)
        except RequestError:
            logger.exception("Exception suppressed by controller, returning None.")
            return None

    return wrapper


class DatabaseController:
    def __init__(self, model: models.Model, endpoint: Endpoint):
        self.model = model
        self.endpoint = endpoint

    @suppress_errors
    def query(self, **kwargs) -> Union[models.Model, List[models.Model]]:
        response = self.endpoint.get(**kwargs)
        query_result = None
        if isinstance(response, list):
            query_result = []
            for item in response:
                model_obj = self.model()
                model_obj.from_db = True
                model_obj.from_dict(item)
                query_result.append(model_obj)
        elif response:
            model_obj = self.model()
            model_obj.from_db = True
            model_obj.from_dict(response)
            query_result = model_obj
        return query_result

    def get(self, **kwargs) -> Union[models.Model, List[models.Model]]:
        return self.query(**kwargs)

    def update(self, model_obj: models.Model, race_condition_check=False) -> Dict:
        # race_condition_check is only supported on certain endpoints
        # if specified on unsupported endpoint will be ignored
        data = model_obj.to_dict(include_nested=False, only_modified=True)
        data["identifier"] = model_obj.id
        if race_condition_check is True:
            data["expected_state_before_update"] = model_obj.snapshot
        res = self.endpoint.put(**data)
        return res

    def put(self, model_obj: models.Model, race_condition_check=False) -> Dict:
        return self.update(model_obj, race_condition_check)

    def insert(
        self, model_obj: Union[models.Model, List[models.Model], None] = None
    ) -> Dict:
        if model_obj is None:
            res = self.endpoint.post()
        elif isinstance(model_obj, list):
            data = [
                mo.to_dict(include_nested=False, only_modified=True) for mo in model_obj
            ]
            res = self.endpoint.post(data)
        else:
            data = model_obj.to_dict(include_nested=False, only_modified=True)
            res = self.endpoint.post(**data)
        return res

    def post(
        self, model_obj: Union[models.Model, List[models.Model], None] = None
    ) -> Dict:
        return self.insert(model_obj)

    @suppress_errors
    def delete(self, identifier) -> Dict:
        res = self.endpoint.delete(identifier)
        return res

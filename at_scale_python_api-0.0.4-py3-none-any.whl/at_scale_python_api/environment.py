import os
import sys

ATS_URL = os.environ.get("ATS_URL")
HOST_NAME = os.environ.get("HOST_NAME", "https://conductor.amd.com")

if not ATS_URL:
    ATS_URL = HOST_NAME

ATS_SECRET = os.environ.get("ATS_SECRET")
AMD_EMAIL = os.environ.get("AMD_EMAIL")

BOOL_STRINGS = {"true": True, "false": False}
VERIFY_CERTS = BOOL_STRINGS.get(os.environ.get("VERIFY_CERTS", "True").lower(), True)

REQUEST_TIMEOUT = int(os.environ.get("REQUEST_TIMEOUT", 30))
